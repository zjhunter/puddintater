#######################################################################
#                  Flush the Perl Buffer. 		   	      			  #
#######################################################################
	# The script begins by telling the Perl interpreter that
	# it should continuously flush its buffer so that text
	# from this script is sent directly to the Web Browser.
	# We do this to streamline debugging and make sure that
	# the script operates with the flow we want it to.

$|=1;

$cgiPath = '/puddintater/cgi-bin';

sub loadHints
{
	my ($val, @hint, $inFile);
	$inFile = shift;

	#takes a file handle as it's argument & initializes the global %hints hash
	while(<$inFile>)
	{
		$i++;
		#ID|Priority|PriceRange|Title|Description|Location|Claimed|Buyer
		@hint = split /\|/;

		$hints{$hint[0]} = {
			ID => $hint[0],
			Priority => $hint[1],
			PriceRange => $hint[2],
			Title => $hint[3],
			Description => $hint[4],
			Location => $hint[5],
			Claimed => $hint[6],
			Buyer => $hint[7]
			};
			#print "Just added hint with id = $hint[0] (${$hints{1}}{Title})\n";
	}
	#print "Added $i hint(s) with id = ${$hints{1}}{ID}\n";
}

sub saveHint
{
	my($fileName, %hint) = @_;
	my(@wishlist, $written);

	#build out the hint value array
	@hintArray = (
		$hint{ID},
		$hint{Priority},
		$hint{PriceRange},
		$hint{Title},
		$hint{Description},
		$hint{Location},
		$hint{Claimed},
		$hint{Buyer}
		);

	#look for the hint ID in the file & overwrite if it's there, else, write a new one.
	open(WISHLIST, "$fileName") or die "error opeining file $fileName to read";
	@wishlist = <WISHLIST>;
	close(WISHLIST);

	open(WISHLIST, ">$fileName") or die "error opeining file $fileName to write";

	foreach $line (@wishlist)
	{
		chomp($line);
		if($line =~ /^$hint{ID}\|/)
		{
			$written = 1;
			$line = join("|", @hintArray);
		}
		print WISHLIST "$line\n";
	}

	#if we haven't updated a line, write the new line
	if(!$written) { print WISHLIST join("|", @hintArray); }

	close(WISHLIST);
}

sub deleteHint
{
	my($fileName, $hintId) = @_;
	my(@wishlist);

	#look for the hint ID in the file & overwrite if it's there, else, write a new one.
	open(WISHLIST, "$fileName") or die "error opeining file $fileName to read";
	@wishlist = <WISHLIST>;
	close(WISHLIST);

	open(WISHLIST, ">$fileName") or die "error opeining file $fileName to write";

	foreach $line (@wishlist)
	{
		chomp($line);
		if(!($line =~ /^$hintId\|/)) { print WISHLIST "$line\n"; }
	}

	close(WISHLIST);
}

sub moveHint
{
	my($otherName, $hintId, $userName) = @_;
	my(@srcList, $srcFN, $targetFN, @hint, %hintItem);

	$srcFN = "$appDirName/tnihs/$otherName\_tnih.dat";
	$targetFN = "$appDirName/shoppinglists/$userName\_shoppinglist.dat";

	#look for the hint ID in the file & overwrite if it's there, else, write a new one.
	open(SRC, "$srcFN") or die "error opeining file $srcFN to read";
	@srcList = <SRC>;
	close(SRC);

	open(SRC, ">$srcFN") or die "error opeining file $srcFN to write";
	open(TARGET, ">>$targetFN") or die "error opeining file $targetFN to write";

	foreach $line (@srcList)
	{
		chomp($line);
		if(!($line =~ /^$hintId\|/))
		{
			#print "Skipping line $line";
			print SRC "$line\n";
		}
		else
		{
			#print "Moving line $line";

			@hint = split /\|/, $line;

			%hintItem = (
				ID => $hint[0],
				Priority => $hint[1],
				PriceRange => $hint[2],
				Title => $hint[3],
				Description => $hint[4],
				Location => $hint[5],
				Claimed => $hint[6],
				Buyer => $hint[7]
				);

			$hintItem{Claimed} = "Y";
			$hintItem{Buyer} = $userName;

			@hintArray = (
				$hintItem{ID},
				$hintItem{Priority},
				$hintItem{PriceRange},
				$hintItem{Title},
				$hintItem{Description},
				$hintItem{Location},
				$hintItem{Claimed},
				$hintItem{Buyer}
				);

			print SRC join("|", @hintArray) . "\n";

			$hintArray[0] = $otherName . $hintItem{ID};
			$hintArray[6] = $otherName;
			$hintArray[7] = "";

			#@hintArray = (
			#	$hintItem{ID},
			#	$hintItem{Priority},
			#	$hintItem{PriceRange},
			#	$hintItem{Title},
			#	$hintItem{Description},
			#	$hintItem{Location},
			#	$otherName
			#	);

			print TARGET join("|", @hintArray) . "\n";
		}
	}

	close(SRC);
	close(TARGET);
}

sub loadShoppingList
{
	my ($val, @gift, $inFile);
	$inFile = shift;

	#takes a file handle as it's argument & initializes the global %shoppingList hash

	while(<$inFile>)
	{
		#ID|Priority|PriceRange|Title|Description|Location|Claimed|Recipient
		@gift = split /\|/;
		foreach $val (@gift)
		{
			$shoppingList{$gift[7] . $gift[0]} = {
				ID => $gift[0],
				Priority => $gift[1],
				PriceRange => $gift[2],
				Title => $gift[3],
				Description => $gift[4],
				Location => $gift[5],
				Recipient => $gift[6]
				};
		}
	}
}

sub getNextHintId
{
	my ($val, @gift, $fileName, $userName);

	$userName = shift;

	$fileName = "$appDirName/login/$userName\_login.dat";
	open(LOGIN, $fileName) or die "error opeining file $fileName";

	@login = <LOGIN>;
	close(LOGIN);

	$fileName = "$appDirName/login/$userName\_login.dat";
	open(LOGIN, ">$fileName") or die "error opeining file $fileName";

	foreach $line (@login)
	{
		if($line =~ /NextHintKey=([0-9]+)/)
		{
			$val = $1 + 1;
			$line = "NextHintKey=$val";
		}
		print LOGIN $line;
	}

	close(LOGIN);
	$val;
}

sub buildSelectList
{
	my(%options, $optionName, $selectedVal, $html, $sel);

	($optionName, $selectedVal, %options) = @_;

	$html = "<select name=\"$optionName\">\n";

	foreach $optName (sort keys(%options))
	{
		$sel = (($options{$optName} == $selectedVal)? "selected": "");
		$html .= "<option value=\"$options{$optName}\" $sel>$optName\n";
	}


	$html .= "</select>\n";
}

sub buildPriceRange
{
	my($priceRange, %options, $ret);

	$priceRange = shift;

	%options = (
		'1 ($0-$20)' => "0-20",
		'2 ($20-$40)' => "20-40",
		'3 ($40-$60)' => "40-60",
		'4 ($60-$100)' => "60-100",
		'5 ($100-$200)' => "100-200",
		'6 ($200+)' => "200+"
			);

	buildSelectList("price", $priceRange, %options);
}

sub buildPriority
{
	my($priority, %options, $ret);

	$priority = shift;

	%options = (
		'1 (Wicked High)' => "1",
		'2 (So So)' => "2",
		'3 (It\'d be nice...)' => "3"
		);

	buildSelectList("priority", $priority, %options);
}

sub drawHome
{
	my $userName = shift;

	### Get the hint list to display
	# hints loaded into %hints hash with the hint's id as the key
	$fileName = "$appDirName/tnihs/$userName\_tnih.dat";
	open(WISHLIST, $fileName) or die "error opeining file $fileName";

	loadHints(\*WISHLIST);
	close(WISHLIST);

	### Build out the list section HTML
	# hints stored in %hints
	foreach $hintId (keys(%hints))
	{

		$hint = $hints{$hintId};
		%hintReplaceTags = (
			hintId => $$hint{ID},
			priority => $$hint{Priority},
			priceRange => $$hint{PriceRange},
			title => $$hint{Title},
			description => $$hint{Description},
			location  => $$hint{Location},
			cgiPath => $cgiPath,
			userName => $userName
			);

		$hintListHTML .= &useTemplate("myHintListItem.html", %hintReplaceTags);
	}

	### Display the response page
	print "Content-Type: text/html\n\n";

	%replaceTags = (
		"userName" => $Form{"userName"},
		"hintList" => $hintListHTML,
		);
	$content = useTemplate("myHintList.html", %replaceTags);

	#note: useTemplate gets the template files from the templates dir automatically
	%replaceTags = (
		"userName" => $Form{"userName"},
		"cgiPath" => $cgiPath,
		"content" => $content
		);

	print useTemplate("CLFrame.html", %replaceTags);
}

sub drawTheirHintList
{
	my ($otherName, $userName) = @_;

	my ($fileName,
		$hint,
		$hintId,
		%hintReplaceTags,
		$hintListHTML,
		%replaceTags,
		$content);

	### Get the hint list to display
	# hints loaded into %hints hash with the hint's id as the key
	$fileName = "$appDirName/tnihs/$otherName\_tnih.dat";
	open(WISHLIST, $fileName) or die "error opeining file $fileName";

	loadHints(\*WISHLIST);
	close(WISHLIST);

	### Build out the list section HTML
	# hints stored in %hints
	foreach $hintId (keys(%hints))
	{
		$hint = $hints{$hintId};
		#Only show unclaimed hints
		if( !( $$hint{Claimed} eq "Y" ) )
		{
			%hintReplaceTags = (
				hintId => $$hint{ID},
				priority => $$hint{Priority},
				priceRange => $$hint{PriceRange},
				title => $$hint{Title},
				description => $$hint{Description},
				location  => $$hint{Location},
				cgiPath => $cgiPath,
				userName => $userName,
				otherName => $otherName
				);

			$hintListHTML .= &useTemplate("theirHintListItem.html", %hintReplaceTags);
		}
	}

	### Display the response page
	#print "Content-Type: text/html\n\n";

	%replaceTags = (
		"userName" => $Form{"userName"},
		"otherName" => $Form{"otherName"},
		"hintList" => $hintListHTML,
		);
	$content = useTemplate("theirHintList.html", %replaceTags);

	#note: useTemplate gets the template files from the templates dir automatically
	%replaceTags = (
		"userName" => $Form{"userName"},
		"otherName" => $Form{"otherName"},
		"cgiPath" => $cgiPath,
		"content" => $content
		);

	print useTemplate("CLFrame.html", %replaceTags);
}

#return true for the package loading
1;
