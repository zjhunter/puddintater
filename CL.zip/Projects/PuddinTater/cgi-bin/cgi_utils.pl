##############################################################################

##############################################################################
# Define Variables                                                           #
# Done                                                                       #
##############################################################################

#return true for the package loading
1;

sub get_date
{
    # Define arrays for the day of the week and month of the year.           #
    @days   = ('Sunday','Monday','Tuesday','Wednesday',
               'Thursday','Friday','Saturday');
    @months = ('January','February','March','April','May','June','July',
	         'August','September','October','November','December');

    # Get the current time and format the hour, minutes and seconds.  Add    #
    # 1900 to the year to get the full 4 digit year.                         #
    ($sec,$min,$hour,$mday,$mon,$year,$wday) = (localtime(time))[0,1,2,3,4,5,6];
    $time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
    $year += 1900;

    # Format the date.                                                       #
    $date = "$days[$wday], $months[$mon] $mday, $year at $time";
}

sub parse_form
{
	my(
		$buffer,
		@pairs
		);
    # Determine the form's REQUEST_METHOD (GET or POST) and split the form   #
    # fields up into their name-value pairs.  If the REQUEST_METHOD was      #
    # not GET or POST, send an error.                                        #
    if($ENV{'REQUEST_METHOD'} eq 'GET')
    {
        # Split the name-value pairs
        @pairs = split(/&/, $ENV{'QUERY_STRING'});
    }
    elsif($ENV{'REQUEST_METHOD'} eq 'POST')
    {
        # Get the input
        read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

        # Split the name-value pairs
        @pairs = split(/&/, $buffer);
    }
    else
    {
        &error('request_method');
    }

    # For each name-value pair:                                              #
    foreach $pair (@pairs)
    {

        # Split the pair up into individual variables.                       #
        local($name, $value) = split(/=/, $pair);

        # Decode the form encoding on the name and value variables.          #
        $name =~ tr/+/ /;
        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;


		# Put each name/value pair into the hash %Form, appending the value  	#
		# with a '; ' if there is already a value present.  We also save the 	#
		# order of the form fields in the  @Field_Order array so we can use  	#
		# this order for the generic sort.  									#

		if($Form{$name} && $value)
		{
			#print "Adding $name\n";
			$Form{$name} = "$Form{$name}; $value";
		}
		elsif($value)
		{
			#print "Adding $name = $value\n";
			push(@Field_Order,$name);
			$Form{$name} = $value;
		}

    }#end foreach @pairs

}#end sub parse_form

sub check_required
{
    # Localize the variables used in this subroutine.                        #
    local($require, @error);

    if($Form{'required_'})
    {
    	@required = split($Form{'required_'}, ";");

		# For each require field defined in the form:                            #
		foreach $require (@required)
		{
			# If it is a regular form field which has not been filled in or      #
			# filled in with a space, flag it as an error field.                 #
			if(!$Form{$require})
			{
				push(@error,$require);
			}
		}#end @required foreach

		# If any error fields have been found, send error message to the user.   #
		if(@error) { &error('missing_fields', @error) }
	}#end required_ if
}#end sub check_required

sub error
{
    # Localize variables and assign subroutine input.                        #
    local($error,@error_fields) = @_;
    local($host,$missing_field,$missing_field_list, %replaceTags);

    if($error eq 'missing_fields')
    {

		foreach $missing_field (@error_fields)
		{
			$missing_field_list .= "      <li>$missing_field\n";
		}

		%replaceTags = {'<!--#missingFieldList#-->', $missing_field_list};
		print(useTemplate('requiredFieldError.html', %replaceTags));
    }
    exit;
}#end sub error

sub useTemplate
{
	local($templateFileName, %replaceTags) = @_;
	local($html);

	#open the template file
	open(TEMPLATE, "$appDirName/templates/$templateFileName") || die "Can't Open Template $templateFileName: $!\n";

	#read the template file into one string
	while(<TEMPLATE>)
	{
		$html .= $_;
	}
	close(TEMPLATE);

	#replace each tag with the appropriate value
	foreach $tag (keys(replaceTags))
	{
		$rep = "<!--\#$tag\#-->";
		#print "replacing $rep with $replaceTags{$tag}\n";
		$html =~ s/$rep/$replaceTags{$tag}/egs;
		#print "\$html = $html";
	}

	#return the result
	return $html;
}